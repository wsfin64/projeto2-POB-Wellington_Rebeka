// Alunos: Wellington da Silva e Rebeka Moreira

package dao;

import modelo.Usuario;

public class DAOUsuario extends DAO<Usuario>{
	
	public Usuario read(Object chave) {
		String chaveUsuario = (String) chave;
		Usuario usuario = manager.find(Usuario.class, chaveUsuario);
		return usuario;
	}

}
