package dao;

import modelo.Administrador;

public class DAOAdministrador extends DAO<Administrador> {
	
	public Administrador read(Object chave) {
		if(chave == null) return null;
		
		String emailAdmin = (String) chave;
		Administrador adm = manager.find(Administrador.class, emailAdmin);
		return adm;
	}

}
