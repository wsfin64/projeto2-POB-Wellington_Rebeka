package dao;

import java.util.List;

import javax.persistence.Query;
import javax.persistence.TypedQuery;

import modelo.Mensagem;

public class DAOMensagem extends DAO<Mensagem> {
	
	public Mensagem read(Object chave) {
		
		if (chave == null) return null;
		
		int idChave = (Integer) chave;
		Mensagem mensagem = manager.find(Mensagem.class, idChave);
		return mensagem;
	}
	
	public List<Mensagem> listarMensagens(String termo){
		TypedQuery<Mensagem> q = manager.createQuery("select m from Mensagem m where m.texto like :n" , Mensagem.class);
		q.setParameter("n", "%" + termo + "%");
		List<Mensagem> mensagens = q.getResultList(); 
		return mensagens;
	}
	
}
