// Alunos: Wellington da Silva e Rebeka Moreira

package dao;

import modelo.Log;

public class DAOLog extends DAO<Log>{
	
	public Log read(Object chave) {
		
		if (chave == null) return null;
		
		String nomeLog = (String) chave;
		Log log = manager.find(Log.class, nomeLog);
		return log;
	}

}
