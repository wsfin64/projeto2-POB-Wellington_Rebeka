package fachada;

import java.util.List;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;

import org.hibernate.service.spi.Manageable;

import dao.DAO;
import dao.DAOLog;
import dao.DAOMensagem;
import dao.DAOUsuario;
import modelo.Administrador;
import modelo.Log;
import modelo.Mensagem;
import modelo.Usuario;

public class Fachada {
	private static DAOUsuario daousuario = new DAOUsuario();  
	private static DAOMensagem daomensagem = new DAOMensagem();  
	private static DAOLog daolog = new DAOLog();  

	private static Usuario usuariologado=null;


	public static void inicializar() {
		DAO.open();
	}

	public static void finalizar(){
		DAO.close();
	}

	public static List<Usuario> listarUsuarios() {
		// nao precisa estar logado
		return daousuario.readAll();	
	}
	public static List<Mensagem> listarMensagens() {
		// nao precisa estar logado
		return daomensagem.readAll();	
	}

	public static List<Log> listarLogs() {
		// nao precisa estar logado
		return daolog.readAll();	
	}
	public static List<Mensagem> buscarMensagens(String termo) throws  Exception{
		/*
		 * nao precisa estar logado
		 * query no banco para obter mensagens do grupo que contenha
		 *  o termo (considerar case insensitive)
		 * 
		 */
		
		List<Mensagem> mensagens = daomensagem.listarMensagens(termo);

		if (mensagens == null){
			throw new Exception("Não foram encontradas mensagens com este termo");
		}else {
			return mensagens;
		}
	}

	public static Usuario criarUsuario(String nome, String senha) throws  Exception{
		
		if (nome.equals("") || senha.equals("") ) throw new Exception("Senha e/ou usuario vazio(s)");
		
		// nao precisa estar logado
		DAO.begin();	
		Usuario u = daousuario.read(nome+"/"+senha);	
		if(u != null) {
			DAO.rollback();	
			throw new Exception("criar usuario - usuario existente:" + nome);
		}

		u = new Usuario(nome+"/"+senha);
		daousuario.create(u);		
		DAO.commit();
		return u;
	}


	public static void login(String nome, String senha) throws Exception{		
		//verificar se ja existe um usuario logada
		if(usuariologado!=null)
			throw new Exception ("ja existe um usuario logado"+usuariologado.getNome());

		DAO.begin();	
		Usuario u = daousuario.read(nome+"/"+senha);	
		if(u == null) {
			DAO.rollback();	
			throw new Exception("login - usuario inexistente:" + nome);
		}
		if(!u.ativo()) {
			DAO.rollback();	
			throw new Exception("login - usuario nao ativo:" + nome);
		}
		usuariologado = u;		//altera o logado na fachada

		Log log = new Log(usuariologado.getNome() + " - login");
		daolog.create(log);
		DAO.commit();
	}
	public static void logoff() throws Exception {	
		
		if (usuariologado == null) throw new Exception("Nenhum usuario logado");
		
		DAO.begin();
		Log log = new Log(usuariologado.getNome() + " - logoff");
		daolog.create(log);
		DAO.commit();

		usuariologado = null; 		//altera o logado na fachada
	}

	public static Usuario getLogado() {
		return usuariologado;
	}

	public static Mensagem criarMensagem(String texto) throws Exception{
		
		DAO.begin();
		
		if (usuariologado == null) {
			DAO.rollback();
			throw new Exception("Usuario não logado");
		}
		
		Mensagem m = new Mensagem(usuariologado, texto);
		daomensagem.create(m);
	
		usuariologado.adicionar(m);
		daousuario.update(usuariologado);
		DAO.commit();

		return m;
	}

	public static List<Mensagem> listarMensagensUsuario() throws Exception{
		/*
		 * tem que esta logado
		 * retorna todas as mensagens do usuario logado
		 * 
		 */
		
		if (usuariologado == null){
			throw new Exception("Usuário não logado");
		}

		return usuariologado.getMensagens();
	}

	public static void apagarMensagens(int... ids) throws  Exception{
		/*
		 * tem que esta logado
		 * recebe uma lista de numeros de id 
		 * (id � um numero entre 1 a N, onde N � a quatidade atual de mensagens do grupo)
		 * validar se ids s�o de mensagens criadas pelo usuario logado
		 * (um usuario nao pode apagar mensagens de outros usuarios)
		 * 
		 * remover cada mensagem da lista de mensagens do usuario logado
		 * apagar cada mensagem do banco 
		 */
		
		DAO.begin();
		if (usuariologado == null){
			throw new Exception("Usuario nao logado");
		}

		for (int id : ids){
			Mensagem mensagem = daomensagem.read(id);

			if (mensagem.getCriador().getNomeSenha().equals(usuariologado.getNomeSenha())){
				daomensagem.delete(mensagem);
			} else {
				throw new Exception("Voce nao pode apagar mensagem de outro usuario");
			}
		}
		DAO.commit();
	}

	public static void sairDoGrupo() throws  Exception{
		/*
		 * tem que esta logado
		 * 
		 * criar a mensagem "fulano saiu do grupo"
		 * desativar o usuario logado e fazer logoff dele
		 */
		
		DAO.begin();
		
		if (usuariologado == null){
			DAO.rollback();
			throw new Exception("Usuario nao logado");
		}
		
		usuariologado.desativar();
		daousuario.update(usuariologado);
		Fachada.criarMensagem(usuariologado.getNome() + " saiu do grupo");
		DAO.commit();
		usuariologado = null;
	}

		public static int totalMensagensUsuario() throws Exception{
			/*
			 * tem que esta logado
			 * retorna total de mensagens criadas pelo usuario logado
			 * 
			 */
			
			if (usuariologado == null){
				throw new Exception("Usuario nao logado");
			}
			
			return usuariologado.getMensagens().size();
		}

	public static void esvaziar() throws Exception{
		DAO.clear();
	}

	/**************************************************************
	 * 
	 * NOVOS M�TODOS DA FACHADA PARA O PROJETO 2
	 * 
	 **************************************************************/

	public static Administrador criarAdministrador(String nome, String senha, String email) throws  Exception{
		// nao precisa estar logado
		DAO.begin();	
		Usuario u = daousuario.read(nome+"/"+senha);	
		if(u != null) {
			DAO.rollback();	
			throw new Exception("criar administrador - usuario ja existe:" + nome);
		}

		Administrador ad = new Administrador(nome+"/"+senha, email);
		daousuario.create(ad);		
		DAO.commit();
		return ad;
	}

	public static void solicitarAtivacao(String nome, String senha) throws  Exception{
		/*
		 * o usuario (nome+senha) tem que estar desativado
		 *  
		 * enviar um email para o administrador com a mensagem "nome solicita ativa��o"
		 * usar o m�todo Fachada.enviarEmail(...) 
		 * 
		 */
		
		String chave = nome + "/" + senha;
		Usuario usuario = daousuario.read(chave);
		
		System.out.println(usuario);
		
		if (usuario == null) {
			throw new Exception("Nome ou senha incorretos");
		}
		
		boolean status = usuario.ativo();
		
		if (usuario.ativo()) {
			throw new Exception("O usuário já está ativo!");
		}
		
		Fachada.enviarEmail("ativacao de conta", nome + " solicita ativacao");
	
	}

	public static void solicitarExclusao(String nome, String senha) throws  Exception{
		/*
		 * o usuario (nome+senha) tem que estar desativado
		 *  
		 * enviar um email para o administrador com a mensagem "nome solicita exclus�o"
		 * usar o m�todo Fachada.enviarEmail(...) 
		 * 
		 */
		
		String chave = nome + "/" + senha;
		Usuario usuario = daousuario.read(chave);
		
		if (usuario == null) throw new Exception("Nome ou senha incorretos");
		
		if (usuario.ativo()) throw new Exception("O usuário está ativo!");
		
		Fachada.enviarEmail("Exclusao de conta", nome + " solicita exclusao");
	}

	public static void ativarUsuario(String nome) throws  Exception{
		/*
		 * o usuario logado tem que ser um administrador  e o usuario a 
		 * ser ativado (nome) tem que estar desativado 
		 *  
		 * ativar o usuario 
		 * criar a mensagem "nome entrou no grupo"
		 * 
		 */
		
		DAO.begin();
		
		if (usuariologado == null) throw new Exception("Usuario administador nao logado");
		
		if (usuariologado.getClass() != Administrador.class){
			DAO.rollback();
			throw new Exception("Voce nao tem permissao para isto!");
		}
		
		Usuario usuarioAtivacao = null;
		List<Usuario> listaUsuarios = daousuario.readAll();
		
		for (Usuario usuario : listaUsuarios) {
			if (usuario.getNome().equals(nome) && usuario.ativo() == false) {
				usuarioAtivacao = usuario;
				break;
			}
		}
		
		if (usuarioAtivacao == null) {
			DAO.rollback();
			throw new Exception("Nao foram encontrados usuarios desativados com o nome informado");
		}
		
		
		usuarioAtivacao.ativar();
		Fachada.criarMensagem(usuarioAtivacao.getNome() + " entrou no grupo");
		DAO.commit();
	}

	public static void apagarUsuario(String nome) throws  Exception{
		/*
		 * o usuario logado tem que ser um administrador  e o usuario a 
		 * ser apagado tem que estar desativado (e n�o pode ser do tipo Administrador)
		 *  
		 * apagar as mensagens do usuario e apagar o usuario 
		 * criar a mensagem "nome foi excluido do sistema"
		 */
		
		DAO.begin();
		
		if (usuariologado == null) throw new Exception("Usuario administador nao logado");
		
		if (usuariologado.getClass() != Administrador.class){
			DAO.rollback();
			throw new Exception("Voce nao tem permissao para isto!");
		}
		
		Usuario usuarioExclusao = null;
		List<Usuario> listaUsuarios = daousuario.readAll();
		
		for (Usuario usuario : listaUsuarios) {
			if (usuario.getNome().equals(nome) && usuario.ativo() == false) {
				usuarioExclusao = usuario;
				break;
			}
		}
		
		if (usuarioExclusao == null) {
			DAO.rollback();
			throw new Exception("Nao foram encontrados usuarios desativados com o nome informado");
		}
		
		String nomeExcluido = usuarioExclusao.getNome();
		daousuario.delete(usuarioExclusao);
		Fachada.criarMensagem(nomeExcluido + " foi excluido do sistema");
		DAO.commit();
	}


	/**************************************************************
	 * 
	 * M�TODO PARA ENVIAR EMAIL, USANDO UMA CONTA (SMTP) DO GMAIL
	 * ELE ABRE UMA JANELA PARA PEDIR A SENHA DO EMAIL DO EMITENTE
	 * ELE USA A BIBLIOTECA JAVAMAIL (ver pom.xml)
	 * Lembrar de: 
	 * 1. desligar antivirus e de 
	 * 2. ativar opcao "Acesso a App menos seguro" na conta do gmail
	 * 
	 **************************************************************/
	public static void enviarEmail(String assunto, String mensagem) {
		try {
			/*
			 * ********************************************************
			 * Obs: lembrar de desligar antivirus e 
			 * de ativar "Acesso a App menos seguro" na conta do gmail
			 * 
			 * pom.xml contem a dependencia javax.mail
			 * 
			 * ********************************************************
			 */
			//configurar emails
			String emailorigem = "xxxxxxxxxxxxx@gmail.com";
			String senhaorigem = pegarSenha();
			String emaildestino = "wsfin64@gmail.com";

			//Gmail
			Properties props = new Properties();
			props.put("mail.smtp.starttls.enable", "true");
			props.put("mail.smtp.host", "smtp.gmail.com");
			props.put("mail.smtp.port", "587");
			props.put("mail.smtp.auth", "true");

			Session session;
			session = Session.getInstance(props,
					new javax.mail.Authenticator() {
				protected PasswordAuthentication getPasswordAuthentication() {
					return new PasswordAuthentication(emailorigem, senhaorigem);
				}
			});

			MimeMessage message = new MimeMessage(session);
			message.setSubject(assunto);		
			message.setFrom(new InternetAddress(emailorigem));
			message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(emaildestino));
			message.setText(mensagem);   // usar "\n" para quebrar linhas
			Transport.send(message);

			//System.out.println("enviado com sucesso");

		} catch (MessagingException e) {
			System.out.println(e.getMessage());
		}
	}
	
	/*
	 * JANELA PARA DIGITAR A SENHA DO EMAIL
	 */
	public static String pegarSenha(){
		JPasswordField field = new JPasswordField(10);
		field.setEchoChar('*'); 
		JPanel painel = new JPanel();
		painel.add(new JLabel("Entre com a senha do email:"));
		painel.add(field);
		JOptionPane.showMessageDialog(null, painel, "Senha", JOptionPane.PLAIN_MESSAGE);
		String texto = new String(field.getPassword());
		return texto.trim();
	}
}

